// function table() {
//     for (var i = 1; i <= 10; i++) {
//         document.write(`${i} x 2 = ${i*2} <br>`);
//     }
// }

function getValue(e) {
    var getInp = document.getElementById("getInp");
    getInp.value += e
}

function eq() {
    var getInp = document.getElementById("getInp");
    getInp.value = eval(getInp.value)
}

function clrall() {
    document.getElementById('getInp').value = ''
}

function clr() {
    var getInp = document.getElementById("getInp").value;
    getInp.value = getInp.slice(0, -1);
}