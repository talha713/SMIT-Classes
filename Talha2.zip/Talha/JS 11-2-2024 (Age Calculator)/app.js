// Task No 1 -------------------------------------------------------------------------------------------------------------------------------

// var month = [ 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

// var date = new Date()
// var currentMonth = month[date.getMonth()]

// document.write(currentMonth)



// Task No 2 -------------------------------------------------------------------------------------------------------------------------------







// Task No 3 -------------------------------------------------------------------------------------------------------------------------------

var date = new Date().getTime
var myAge = new Date()