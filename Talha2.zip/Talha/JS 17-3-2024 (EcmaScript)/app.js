var arrayOfObj = [
    {
        p_id: 1,
        p_name: "samsung",
        p_price: "25000",
        p_image: "https://cubeonline.pk/cdn/shop/products/FLRC-214-B0-Burgundy-01-PDP-GALLERY-1600x1200_800x.jpg?v=1696490551"
    },
    {
        p_id: 2,
        p_name: "iphone",
        p_price: "225000",
        p_image: "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/iphone-card-40-iphone15prohero-202309_FMT_WHH?wid=508&hei=472&fmt=p-jpg&qlt=95&.v=1693086369818"
    },
    {
        p_id: 3,
        p_name: "motorola",
        p_price: "12000",
        p_image: "https://images.priceoye.pk/motorola-moto-g84-5g-pakistan-priceoye-kst47-500x500.webp"
    },
    {
        p_id: 4,
        p_name: "oppo",
        p_price: "27000",
        p_image: "https://www.oppo.com/content/dam/oppo/common/mkt/v2-2/a57-en/navigation/A57-427x600-green.png"
    }
]

var products = document.getElementById('show')

function showProducts() {
    var pro = arrayOfObj[0]
    var pid = document.createElement('p')
    pid.innerHTML = pro.p_id
    products.appendChild(pid)

    var pname = document.createElement('p')
    pname.innerHTML = pro.p_name
    products.appendChild(pname)

    var pprice = createElement('p')
    pprice.innerHTML = pro.p_price
    products.appendChild(pprice)

    var pimage = createElement('img')
    pimage.inner

}