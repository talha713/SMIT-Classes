
// var getUl = document.getElementById('getUl');

// function addtodo() {
//     var getInp = document.getElementById('inp');
//     var createLi = document.createElement('li');
//     var liText = document.createTextNode(getInp.value);
//     createLi.appendChild(liText);
//     getUl.appendChild(createLi);
//     getInp.value = '';
// }

var getUl = document.getElementById('getUl');

function addtodo() {
    var getInp = document.getElementById('inp');
    var createLi = document.createElement('li');
    var liText = document.createTextNode(getInp.value);
    createLi.appendChild(liText);
    getUl.appendChild(createLi);
    getInp.value = '';
}