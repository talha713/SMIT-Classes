function signup() {
    var getEmail = document.querySelector('#email').value
    var getPass = document.querySelector('#pass').value
    localStorage.setItem('email',getEmail)
    localStorage.setItem('password',getPass)
    alert('Sign Up Successful')
    location.href = './signin.html'
}

function signin() {
    var getEmail = document.querySelector('#semail').value
    var getPass = document.querySelector('#spass').value
    if (localStorage.getItem('email') == getEmail && localStorage.getItem('password') == getPass) {
        alert('Login Successful')
        location.href = './welcome.html'
    } else {
        alert('Invalid Credentials')
        location.href = './signup.html'
    }
}